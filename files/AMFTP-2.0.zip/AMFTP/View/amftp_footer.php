<div id="footer">
Copyright © AMFTP 2.0 <a href="http://amysql.com" target="_blank">Amysql.com</a> All Rights Reserved <a href="./index.php?c=index&a=help" >使用帮助</a>
<br />
<br />
</div>

</body>
</html>