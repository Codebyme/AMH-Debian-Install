<?php !defined('_Amysql') && exit; ?>

<h2>用户管理 & 权限组</h2>
<div id="category">
<a href="index.php?c=admin&a=user_list" id="user_list" >用户管理</a>
<a href="index.php?c=admin&a=user_grant" id="user_grant">权限组</a>
<script>
var action = '<?php echo $_GET['a'];?>';
var action_dom = G(action) ? G(action) : G('user_list');
action_dom.className = 'activ';
</script>
</div>