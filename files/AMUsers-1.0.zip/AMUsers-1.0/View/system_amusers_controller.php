<?php include('header.php'); ?>
<style>
#STable th {
	padding:4px 6px;
}
#STable td {
padding: 4px 5px 3px 5px;
_padding: 2px 3px;
}
</style>

<div id="body">
<?php include('system_category.php'); ?>

<?php
	if (!empty($notice)) echo '<div style="margin:5px 2px;width:500px;"><p id="' . $status . '">' . $notice . '</p></div>';
?>

<p>AMUsers 控制器管理</p>

<table border="0" cellspacing="1"  id="STable" style="width:auto;">
	<tr>
	<th>&nbsp; ID &nbsp; </th>
	<th width="">&nbsp; 控制器导航名称 &nbsp; </th>
	<th width="">&nbsp; 控制器唯一ID &nbsp; </th>
	<th width="60">排序位置</th>
	<th width="130">时间</th>
	<th width="220">管理</th>
	</tr>
<?php
	foreach ($amusers_controller_list['data'] as $key=>$val)
	{
?>
	<tr>
	<th class="i"><?php echo $val['controller_id'];?></th>
	<td><?php echo $val['controller_name_cn'];?></td>
	<td><?php echo $val['controller_name_en'];?></td>
	<td><?php echo $val['controller_order'];?></td>
	<td><?php echo $val['controller_time'];?></td>
	<td>
		<a href="index.php?c=system&a=amusers_controller&edit=<?php echo $val['controller_id'];?>" class="button"><span class="pen icon"></span>编辑</a>
		<a href="index.php?c=system&a=amusers_controller&del=<?php echo $val['controller_id'];?>" class="button" onclick="return confirm('确认删除控制器:<?php echo $val['controller_name_cn'] . ' (' . $val['controller_name_en'] . ')';?>?');"><span class="cross icon"></span>删除</a>
	</td>
	</tr>
<?php
	}
?>
</table>
<div id="page_list">总<?php echo $total_page;?>页 - <?php echo $amusers_controller_list['sum'];?>记录 » 页码 <?php echo htmlspecialchars_decode($page_list);?> </div>
<br />

<p><?php echo isset($edit_controller) ? '编辑' : '新增';?>控制器: <?php echo isset($edit_controller) ? $_POST['controller_name_cn'] : '';?></p>
<form action="./index.php?c=system&a=amusers_controller" method="POST" >
<table border="0" cellspacing="1"  id="STable" style="width:650px;">
	<tr>
	<th> &nbsp; </th>
	<th>值</th>
	<th>说明</th>
	</tr>

	<tr><td>控制器导航名称</td>
	<td><input type="text" id="controller_name_cn" name="controller_name_cn" class="input_text" value="<?php echo $_POST['controller_name_cn'];?>" </td>
	<td><p><font class="red">*</font> &nbsp; 自定义控制器导航名称</p>
	<p class="text_eg"> &nbsp; 例如: 虚拟主机  </p>
	</td>
	</tr>
	<tr><td>控制器唯一ID</td>
	<td><input type="text" id="controller_name_en" name="controller_name_en" class="input_text" value="<?php echo $_POST['controller_name_en'];?>" </td>
	<td><p><font class="red">*</font> &nbsp; 自定义控制器唯一ID</p>
	<p class="text_eg"> &nbsp; 例如: host  </p>
	</td>
	</tr>
	<tr><td>控制器排序</td>
	<td><input type="text" id="controller_order" name="controller_order" class="input_text" value="<?php echo $_POST['controller_order'];?>" </td>
	<td><p><font class="red">*</font> &nbsp; 自定义排序，从小至大</p>
	<p class="text_eg"> &nbsp; 例如: 3  </p>
	</td>
	</tr>

</table>

<?php if (isset($edit_controller)) { ?>
	<input type="hidden" name="save_edit" value="<?php echo $_POST['controller_id'];?>" />
<?php } else { ?>
	<input type="hidden" name="save" value="y" />
<?php }?>

<button type="submit" class="primary button" name="submit"><span class="check icon"></span>保存</button> 
</form>


</div>

<?php include('../View/footer.php'); ?>
