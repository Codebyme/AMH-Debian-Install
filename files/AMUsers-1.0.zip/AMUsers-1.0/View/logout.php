<?php include('header.php'); ?>

<div id="body">
<h2>用户退出</h2>

Please wait ...
<script>
window.location = './index.php';
</script>
</div>
<?php include('../View/footer.php'); ?>
