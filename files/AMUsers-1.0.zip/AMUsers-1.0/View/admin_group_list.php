<?php include('header.php'); ?>
<style>
#STable th {
	padding:4px 6px;
}
#STable td {
padding: 4px 5px 3px 5px;
_padding: 2px 3px;
}
#grant_controller_id .item{
	width:22%;
	text-align:left;
	padding:5px;
	display:inline-block;
	float:left;
}
</style>
<script>
var select_grant = function (type)
{
	if(!grant_item)
		var grant_item = getElementByClassName('grant_item', 'input');
	for (var k in grant_item)
	{
		if (type == 'all')
			grant_item[k].checked = true;
		else
			grant_item[k].click();
	}
}
</script>

<div id="body">
<?php include('admin_category.php'); ?>

<?php
	if (!empty($notice)) echo '<div style="margin:5px 2px;width:500px;"><p id="' . $status . '">' . $notice . '</p></div>';
?>

<p>AMUsers 权限组管理</p>

<table border="0" cellspacing="1"  id="STable" style="width:auto;">
	<tr>
	<th>&nbsp; ID &nbsp; </th>
	<th width="120">权限组名称</th>
	<th width="60">用户数量</th>
	<th width="120">时间</th>
	<th width="260">管理</th>
	</tr>
<?php
	foreach ($amusers_group_list['data'] as $key=>$val)
	{
		if (isset($_GET['grant']) && $val['group_id'] == $_GET['grant'])
			$_POST['group_name'] = $val['group_name'];
?>
	<tr>
	<th class="i"><?php echo $val['group_id'];?></th>
	<td><?php echo $val['group_name'];?></td>
	<td><?php echo (int)$val['user_sum'];?> 位</td>
	<td><?php echo $val['group_time'];?></td>
	<td>
		<a href="index.php?c=admin&a=user_grant&edit=<?php echo $val['group_id'];?>" class="button"><span class="pen icon"></span>编辑</a>
		<a href="index.php?c=admin&a=user_grant&grant=<?php echo $val['group_id'];?>" class="button"><span class="key icon"></span>授权控制器</a>
		<a href="index.php?c=admin&a=user_grant&del=<?php echo $val['group_id'];?>" class="button" onclick="return confirm('确认删除权限组:<?php echo $val['group_name'];?>?');"><span class="cross icon"></span>删除</a>
	</td>
	</tr>
<?php
	}
?>
</table>
<div id="page_list">总<?php echo $total_page;?>页 - <?php echo $amusers_group_list['sum'];?>记录 » 页码 <?php echo htmlspecialchars_decode($page_list);?> </div>

<?php
	if (isset($_GET['grant']))
	{
?>
<br />
<p>AMUsers 授权控制器：<?php echo $_POST['group_name'];?></p>
<form action="" method="POST" >
<table border="0" cellspacing="1"  id="STable" style="width:710px;">
<th width="70"><p style="text-align:center">选择授权</p></th>
<td id="grant_controller_id">
<?php 
	if (!is_array($amusers_controller_list_all) || count($amusers_controller_list_all) == 0)
		echo '请先从系统设计中填加控制器';
	else
	{
		foreach ($amusers_controller_list_all as $key=>$val)
		{
?>
			<div class="item">
			<input type="checkbox" name="controller_id_<?php echo $val['controller_id'];?>" id="controller_id_<?php echo $val['controller_id'];?>" <?php echo isset($val['checked']) ? 'checked=""' : '';?> class="grant_item"> <label for="controller_id_<?php echo $val['controller_id'];?>" ><?php echo $val['controller_name_cn'];?></label>
			</div>
<?php
		}
	}
?>
</td>
</table>
<input type="hidden" id="group_name" name="group_name" class="input_text" value="<?php echo $_POST['group_name'];?>">
<button type="submit" class="primary button" name="save_grant"><span class="check icon"></span>保存</button>  <a href="javascript:select_grant('all');">全选</a> / <a href="javascript:select_grant('');">反选</a>
</form>
<?php
	}
	else
	{
?>


<br />
<p><?php echo isset($edit_group) ? '编辑' : '新增';?>权限组: <?php echo isset($edit_group) ? $_POST['group_name'] : '';?></p>
<form action="./index.php?c=admin&a=user_grant" method="POST" >
<table border="0" cellspacing="1"  id="STable" style="width:650px;">
	<tr>
	<th> &nbsp; </th>
	<th>值</th>
	<th>说明</th>
	</tr>

	<tr><td>权限组名称</td>
	<td><input type="text" id="group_name" name="group_name" class="input_text" value="<?php echo $_POST['group_name'];?>" /> </td>
	<td><p><font class="red">*</font> &nbsp; 输入权限组名称</p>
	<p class="text_eg"> &nbsp; 例如: VIP用户  </p>
	</td>
	</tr>

</table>

<?php if (isset($edit_group)) { ?>
	<input type="hidden" name="save_edit" value="<?php echo $_POST['group_id'];?>" />
<?php } else { ?>
	<input type="hidden" name="save" value="y" />
<?php }?>

<button type="submit" class="primary button" name="submit"><span class="check icon"></span>保存</button>
</form>
<?php
	}
?>


</div>

<?php include('../View/footer.php'); ?>
