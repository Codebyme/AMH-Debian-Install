<?php include('header.php'); ?>
<style>
#STable th {
	padding:4px 6px;
}
#STable td {
padding: 4px 5px 3px 5px;
_padding: 2px 3px;
}
#STable li{
	margin:0px;
	padding:0px;
	margin-bottom:3px;
}
#STable ul{
	margin:10px 5px;
	margin-right: 20px;
	background: rgba(232, 243, 255, 0.34);
	padding: 5px 20px 5px 30px;
	border: 1px solid #fff;
}
#STable pre {
	width:540px;
	overflow-x: hidden;
	margin:2px;
	text-align:left;
	max-height: 250px;
}
</style>

<div id="body">
<?php include('system_category.php'); ?>

<?php
	if (!empty($notice)) echo '<div style="margin:5px 2px;width:500px;"><p id="' . $status . '">' . $notice . '</p></div>';
?>

<p>AMUsers 组件管理</p>

<table border="0" cellspacing="1"  id="STable" style="width:auto;">
	<tr>
	<th>&nbsp; ID &nbsp; </th>
	<th width="">&nbsp; 所属控制器 &nbsp; </th>
	<th width="">&nbsp; 父级 &nbsp; </th>
	<th width="">组件类型</th>
	<th width="">排序位置</th>
	<th width="360">管理</th>
	</tr>
<?php
	foreach ($amusers_item_list['data'] as $key=>$val)
	{
		$controller_name_cn = isset($amusers_controller_list_all[$val['controller_id']]) ? $amusers_controller_list_all[$val['controller_id']]['controller_name_cn'] : '';
		$item_type_name = isset($amusers_item_type_list_all[$val['item_type_id']]) ? $amusers_item_type_list_all[$val['item_type_id']]['item_type_name'] : '';
?>
	<tr>
	<th class="i"><?php echo $val['item_id'];?></th>
	<td><?php echo !empty($controller_name_cn) ? $controller_name_cn : '<font class="text_eg">无</font>';?></td>
	<td><?php echo $val['item_parent_id'] == '0' ? '顶级' : '#' . $val['item_parent_id'];?></td>
	<td><?php echo !empty($item_type_name) ? $item_type_name : '<font class="text_eg">无</font>';?></td>
	<td><?php echo $val['item_order'];?></td>
	<td>
		<a href="index.php?c=system&a=amusers_item&edit=<?php echo $val['item_id'];?>" class="button"><span class="pen icon"></span>编辑</a>
		<a href="index.php?c=system&a=amusers_item&item=<?php echo $val['item_id'];?>" class="button"><span class="cog icon"></span>管理组件</a>
		<a href="index.php?c=system&a=amusers_item&property=<?php echo $val['item_id'];?>" class="button"><span class="tag icon"></span>属性</a>
		<a href="index.php?c=system&a=amusers_item&del=<?php echo $val['item_id'];?>" class="button" onclick="return confirm('确认删除组件:<?php echo $item_type_name . ' (' . $val['item_id'] . ')';?>?');"><span class="cross icon"></span>删除</a>
	</td>
	</tr>
<?php
	}
?>
</table>
<div id="page_list">总<?php echo $total_page;?>页 - <?php echo $amusers_item_list['sum'];?>记录 » 页码 <?php echo htmlspecialchars_decode($page_list);?> </div>

<?php
	if (isset($_GET['item']))
	{
		global $CL, $TL;
		$CL = $amusers_controller_list_all;
		$TL = $amusers_item_type_list_all;
		function print_li($data)
		{
			global $CL;
			global $TL;
			echo '<ul>';
			foreach ($data as $key=>$val)
			{
				?>
				<li>
				<?php echo $val['item_id'] == $_GET['son_item'] ? '<b>' : '';?>
				#ID<?php echo $val['item_id'];?> <?php echo $TL[$val['item_type_id']]['item_type_name'];?> &nbsp;
				<?php echo $val['item_id'] == $_GET['son_item'] ? '</b>' : '';?>
				<a href="index.php?c=system&a=amusers_item&item=<?php echo $_GET['item'];?>&son_item=<?php echo $val['item_id'];?>&edit=<?php echo $val['item_id'];?>" class="button"><span class="pen icon"></span>编辑</a>
				<a href="index.php?c=system&a=amusers_item&item=<?php echo $_GET['item'];?>&son_item=<?php echo $val['item_id'];?>" class="button"><span class="cog icon"></span>添加</a>
				<a href="index.php?c=system&a=amusers_item&item=<?php echo $_GET['item'];?>&son_item=<?php echo $val['item_id'];?>&property=<?php echo $val['item_id'];?>" class="button"><span class="tag icon"></span>属性</a>
				<a href="index.php?c=system&a=amusers_item&item=<?php echo $_GET['item'];?>&del=<?php echo $val['item_id'];?>" class="button" onclick="return confirm('确认删除组件:<?php echo $TL[$val['item_type_id']]['item_type_name'] . ' (' . $val['item_id'] . ')';?>?');"><span class="cross icon"></span>删除</a> <font style="color:#A2A2A2"><?php echo $val['item_note'];?></font>
				</li>
				<?php
				if (is_array($val['son']))
				{
					print_li($val['son']);
				}
			}
			echo '</ul>';
		}
?>
<br />
<p>组件视图: #ID <?php echo $_GET['item'];?></p>
<table border="0" cellspacing="1"  id="STable" style="width:auto;">
	<tr>
	<th> <div style="width:500px;">组件视图 & 结构</div> </th>
	</tr>
	<tr>
	<td style="text-align:left">
<?php
	if (is_array($amusers_item_son))
		print_li($amusers_item_son);
	else
	    echo '<p> &nbsp; 请在下面添加新的子组件</p>';
?>
	</td>
	</tr>
</table>
<?php
	}
?>

<?php
	if (isset($_GET['property']))
	{
?>
<br />
<p>组件属性: #ID <?php echo $_GET['property'];?></p>
<form action="./index.php?c=system&a=amusers_item<?php echo isset($_GET['item']) ? "&item={$_GET['item']}":'';?><?php echo isset($_GET['son_item']) ? "&son_item={$_GET['son_item']}":'';?>&property=<?php echo $_GET['property'];?>" method="POST" >
<table border="0" cellspacing="1"  id="STable" style="width:auto;">
	<tr>
	<th>&nbsp; ID &nbsp; </th>
	<th width="">&nbsp; 属性名称 &nbsp; </th>
	<th width="">&nbsp; 属性类型 &nbsp; </th>
	<th width="">&nbsp; 属性值 &nbsp; </th>
	<th width="140">管理</th>
	</tr>
<?php
	foreach ($amusers_property_list as $key=>$val)
	{
?>
	<tr>
	<th class="i"><?php echo $val['property_id'];?></th>
	<td><?php echo $val['property_name'];?></td>
	<td><?php echo $val['property_type'];
	if(!in_array($val['property_type'], array('php', 'html')))
	{
		echo "<br />";
		echo is_object(json_decode(htmlspecialchars_decode($val['property_value']))) ? "<font color='green'>数据正确</font>" : "<font color='red'>数据错误</font>";
	}
	?></td>
	<td width="540"><pre><?php echo $val['property_value'];?></pre></td>
	<td width="140">
		<a href="index.php?c=system&a=amusers_item<?php echo isset($_GET['item']) ? "&item={$_GET['item']}":'';?><?php echo isset($_GET['son_item']) ? "&son_item={$_GET['son_item']}":'';?>&property=<?php echo $_GET['property'];?>&edit_property=<?php echo $val['property_id'];?>" class="button"><span class="pen icon"></span>编辑</a>
		<a href="index.php?c=system&a=amusers_item<?php echo isset($_GET['item']) ? "&item={$_GET['item']}":'';?><?php echo isset($_GET['son_item']) ? "&son_item={$_GET['son_item']}":'';?>&property=<?php echo $_GET['property'];?>&del_property=<?php echo $val['property_id'];?>" class="button" onclick="return confirm('确认删除属性:<?php echo $val['property_name'] . ' (' . $val['property_id'] . ')';?>?');"><span class="cross icon"></span>删除</a>
	</td>
	</tr>
<?php
	}
?>
	<tr>
	<th colspan="5">添加新属性</th>
	</tr>
	<tr>
		<td style="text-align:left;padding:5px 10px;" colspan="5">
		<p>属性命名: </p>
		<input type="text" id="property_name" name="property_name" class="input_text" value="<?php echo isset($_POST['property_name']) ? $_POST['property_name'] : '';?>" /> <font class="red">*</font> (
		<a href="javascript:;" onclick="G('property_name').value='name'">name</a> 
		<a href="javascript:;" onclick="G('property_name').value='id'">id</a>
		<a href="javascript:;" onclick="G('property_name').value='class'">class</a>
		<a href="javascript:;" onclick="G('property_name').value='type'">type</a>
		<a href="javascript:;" onclick="G('property_name').value='style'">style</a>
		<a href="javascript:;" onclick="G('property_name').value='value'">value</a>
		<a href="javascript:;" onclick="G('property_name').value='text'">text</a>
		)<br />
		<p>属性类型: </p>
		<select id="property_type" name="property_type">
		<option value="html">HTML属性</option>
		<option value="php">执行PHP代码</option>
		<option value="sql_data">SQL模板数据</option>
		<option value="amh_data">AMH模板数据</option>
		<option value="sql">SQL语句响应</option>
		<option value="amh">AMH命令响应</option>
		</select> <font class="red">*</font>
		<script>G('property_type').value = '<?php echo isset($_POST['property_type']) ? $_POST['property_type'] : 'html';?>';
		</script>
		<p>属性值: </p>
		<textarea id="property_value" name="property_value" style="display:block;width:780px;height:110px;font-family:宋体;"><?php echo isset($_POST['property_value']) ? $_POST['property_value'] : '';?></textarea>
		<br />
		</td>
	</tr>
</table>
<?php if (isset($edit_property)) { ?>
	<input type="hidden" name="edit_property" value="<?php echo $_POST['property_id'];?>" />
<?php } else { ?>
	<input type="hidden" name="save_property" value="<?php echo $_GET['property'];?>" />
<?php }?>
<button type="submit" class="primary button" name="submit"><span class="check icon"></span>保存</button> 
</form>
<?php
	}
	else
	{
	    
?>


<br />
<p><?php echo isset($edit_item) ? '编辑' : '新增';?>组件: 
<?php echo isset($edit_item) ? '#ID' . $_POST['item_id'] : 
		(isset($_GET['son_item']) ? '#ID' . $_GET['son_item'] : 
			(isset($_GET['item']) ? '#ID' . $_GET['item'] : ' #顶级')
	);?></p>
<?php if (isset($edit_item)) { ?>
<form action="./index.php?c=system&a=amusers_item<?php echo isset($_GET['item']) ? "&item={$_GET['item']}":'';?><?php echo isset($_GET['son_item']) ? "&son_item={$_GET['son_item']}":'';?>" method="POST" >
<?php }else{?>
<form action="" method="POST" >
<?php }?>
<table border="0" cellspacing="1"  id="STable" style="width:650px;">
	<tr>
	<th> &nbsp; </th>
	<th>值</th>
	<th>说明</th>
	</tr>

	<?php if(!isset($_GET['item'])){?>
	<tr><td>所属控制器</td>
	<td>
	<select name="controller_id" id="controller_id">
	<?php
		foreach ($amusers_controller_list_all as $key=>$val)
		{
	?>
		<option value="<?php echo $val['controller_id'];?>"><?php echo $val['controller_name_cn'];?></option>
	<?php
		}
	?>
	<option value="0">无控制器</option>
	</select>
	<script>G('controller_id').value = '<?php echo isset($_POST['controller_id']) ? $_POST['controller_id'] : '0';?>';
	if(G('controller_id').value == '') G('controller_id').value = '0';
	</script>
	</td>
	<td><p><font class="red">*</font> &nbsp; 选择组件所属的控制器</p>
	</td>
	</tr>
	<?php }else{?>
		<input type="hidden" name="controller_id" value="0" /> <!-- 子组件无控制器 -->


		<?php if (isset($edit_item)) { ?>
		<tr><td>父组件ID</td>
		<td>
		<input type="text" id="item_parent_id" name="item_parent_id" class="input_text" value="<?php echo isset($_POST['item_parent_id'])? $_POST['item_parent_id'] : '0';?>" style="width: 300px;"/>
		</td>
		<td><p><font class="red">*</font> &nbsp; 组件所属父组件ID </p><p> &nbsp; 无特殊需要请勿更改 </p>
		</td>
		</tr>
		<?php }?>
	<?php }?>

	

	<tr><td>组件类型</td>
	<td>
	<select name="item_type_id" id="item_type_id">
	<?php
		foreach ($amusers_item_type_list_all as $key=>$val)
		{
	?>
		<option value="<?php echo $val['item_type_id'];?>"><?php echo $val['item_type_name'];?></option>
	<?php
		}
	?>
	<option value="0">无组件类型</option>
	</select>
	<script>G('item_type_id').value = '<?php echo isset($_POST['item_type_id']) ? $_POST['item_type_id'] : '0';?>';
	if(G('item_type_id').value == '') G('item_type_id').value = '0';
	</script>
	</td>
	<td><p><font class="red">*</font> &nbsp; 选择组件类型</p>
	</td>
	</tr>

	<tr><td>组件排序</td>
	<td>
	<input type="text" id="item_order" name="item_order" class="input_text" value="<?php echo isset($_POST['item_order']) ? $_POST['item_order'] : '0';?>" style="width: 300px;"/>
	</td>
	<td><p><font class="red">*</font> &nbsp; 从小至大排序</p>
	</td>
	</tr>

	<tr><td>组件备注</td>
	<td>
	<input type="text" id="item_note" name="item_note" class="input_text" value="<?php echo isset($_POST['item_note']) ? $_POST['item_note'] : '';?>" style="width: 300px;"/>
	</td>
	<td><p> &nbsp; 备注说明组件作用</p>
	</td>
	</tr>

</table>

<?php if (isset($edit_item)) { ?>
	<input type="hidden" name="item_name" value="<?php echo $amusers_controller_list_all[$_POST['controller_id']]['controller_name_cn'];?>" />
	<input type="hidden" name="save_edit" value="<?php echo $_POST['item_id'];?>" />
<?php } else { ?>
	<input type="hidden" name="save" value="y" />
	<input type="hidden" name="item_parent_id" value="<?php echo isset($_GET['son_item'])? $_GET['son_item'] : (isset($_GET['item']) ? $_GET['item'] : '0');?>" />
<?php }?>
<button type="submit" class="primary button" name="submit"><span class="check icon"></span>保存</button> 
</form>
<?php
	}
?>

</div>

<?php include('../View/footer.php'); ?>
