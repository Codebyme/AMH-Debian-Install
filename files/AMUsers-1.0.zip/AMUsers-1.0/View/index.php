<?php include('header.php'); ?>

<div id="body">
	<?php
		include('index_templet.php');
	?>
</div>
<?php include('../View/footer.php'); ?>
