<?php include('header.php'); ?>
<style>
#STable th {
	padding:4px 6px;
}
#STable td {
padding: 4px 5px 3px 5px;
_padding: 2px 3px;
}
.input_text {
	width: 250px;
}
select {
	width: 260px;
}
textarea {
	display: inline-block;
	width: 250px;
	height: 50px;
}
</style>

<div id="body">
<?php include('admin_category.php'); ?>

<?php
	if (!empty($notice)) echo '<div style="margin:5px 2px;width:500px;"><p id="' . $status . '">' . $notice . '</p></div>';
?>
<p>AMUsers 用户管理</p>

<table border="0" cellspacing="1"  id="STable" style="width:auto;">
	<tr>
	<th>&nbsp; ID &nbsp; </th>
	<th width="120">账号名</th>
	<th>权限组</th>
	<th>用户级别</th>
	<th>用户状态</th>
	<th width="130">时间</th>
	<th width="160">管理</th>
	</tr>
<?php
	foreach ($amusers_user_list['data'] as $key=>$val)
	{
?>
	<tr>
	<th class="i"><?php echo $val['user_id'];?></th>
	<td><b><?php echo $val['user_name'];?></b></td>
	<td><?php echo !empty($val['group_name']) ? $val['group_name'] : '<font class="text_eg">无</font>';?></td>
	<td><?php echo $val['admin_user'] == '1' ? '管理员' : '用户';?></td>
	<td><?php echo $val['user_status'] == '1' ? '<font color="green">已开启</font>' : '<font color="red">已关闭</font>';?></td>
	<td><?php echo $val['user_time'];?></td>
	<td>
		<a href="index.php?c=admin&a=user_list&edit=<?php echo $val['user_id'];?>" class="button"><span class="pen icon"></span>编辑</a>
		<a href="index.php?c=admin&a=user_list&del=<?php echo $val['user_id'];?>" class="button" onclick="return confirm('确认删除用户:<?php echo $val['user_name'];?>?');"><span class="cross icon"></span>删除</a>
	</td>
	</tr>
<?php
	}
?>
</table>
<div id="page_list">总<?php echo $total_page;?>页 - <?php echo $amusers_user_list['sum'];?>记录 » 页码 <?php echo htmlspecialchars_decode($page_list);?> </div>
<br />


<p><?php echo isset($edit_user) ? '编辑' : '新增';?>用户: <?php echo isset($edit_user) ? $_POST['user_name'] : '';?></p>
<form action="./index.php?c=admin&a=user_list" method="POST" >
<table border="0" cellspacing="1"  id="STable" style="width:650px;">
	<tr>
	<th> &nbsp; </th>
	<th>值</th>
	<th>说明</th>
	</tr>

	<tr><td>账号名</td>
	<td>
	<input type="text" id="user_name" name="user_name" class="input_text <?php echo isset($edit_user) ? ' disabled' : '';?>" value="<?php echo $_POST['user_name'];?>" <?php echo isset($edit_user) ? 'disabled=""' : '';?>/>
	</td>
	<td><p><font class="red">*</font> &nbsp; 请输入用户名</p>
	</td>
	</tr>
	<tr><td>用户密码</td>
	<td><input type="password" id="user_password" name="user_password" class="input_text" value="<?php echo $_POST['user_password'];?>"> </td>
	<td><p><font class="red">*</font> &nbsp; 请输入用户密码 <?php echo isset($edit_user) ? ' <br />[不更改密码请留空]' : '';?></p>
	</td>
	</tr>
	<tr><td>用户权限组</td>
	<td>
	<select name="group_id" id="group_id">
	<?php
		foreach ($amusers_group_list_all as $key=>$val)
		{
	?>
		<option value="<?php echo $val['group_id'];?>"><?php echo $val['group_name'];?></option>
	<?php
		}
	?>
	<option value="0">无权限组</option>
	</select>
	<script>G('group_id').value = '<?php echo isset($_POST['group_id']) ? $_POST['group_id'] : '0';?>';
	if(G('group_id').value == '') G('group_id').value = '0';
	</script>
	</td>
	<td><p> &nbsp; 选择用户所属权限组</p>
	</td>
	</tr>
	<tr><td>用户级别</td>
	<td>
	<select name="admin_user" id="admin_user">
	<option value="0">用户</option>
	<option value="1">管理员</option>
	</select>
	<script>G('admin_user').value = '<?php echo isset($_POST['admin_user']) ? $_POST['admin_user'] : '0';?>';
	if(G('admin_user').value == '') G('admin_user').value = '0';
	</script>
	</td>
	<td><p> &nbsp; 选择用户所属级别</p>
	</td>
	</tr>
	<tr><td>账号状态</td>
	<td>
	<select name="user_status" id="user_status">
	<option value="1">开启</option>
	<option value="2">关闭</option>
	</select>
	<?php if(isset($_POST['user_status'])) {?>
	<script>G('user_status').value = '<?php echo $_POST['user_status'] == '1' ? '1' : '2';?>';</script>
	<?php } ?>
	</td>
	<td><p> &nbsp; 开启或关闭账号</p>
	</td>
	</tr>
	<tr><td>用户姓名</td>
	<td><input type="text" id="user_info_name" name="user_info_name" class="input_text" value="<?php echo $_POST['user_info_name'];?>"> </td>
	<td><p> &nbsp; 用户姓名 / 称呼</p>
	</td>
	</tr>
	<tr><td>用户Email</td>
	<td><input type="text" id="user_info_email" name="user_info_email" class="input_text" value="<?php echo $_POST['user_info_email'];?>"> </td>
	<td><p> &nbsp; 用户Email地址</p>
	</td>
	</tr>
	<tr><td>用户QQ</td>
	<td><input type="text" id="user_info_qq" name="user_info_qq" class="input_text" value="<?php echo $_POST['user_info_qq'];?>"> </td>
	<td><p> &nbsp; 用户QQ号码</p>
	</td>
	</tr>
	<tr><td>用户电话</td>
	<td><input type="text" id="user_info_tel" name="user_info_tel" class="input_text" value="<?php echo $_POST['user_info_tel'];?>"> </td>
	<td><p> &nbsp; 用户联系电话</p>
	</td>
	</tr>
	<tr><td>公司名称</td>
	<td><input type="text" id="user_company_name" name="user_company_name" class="input_text" value="<?php echo $_POST['user_company_name'];?>"> </td>
	<td><p> &nbsp; 用户公司名称</p>
	</td>
	</tr>
	<tr><td>公司地址</td>
	<td><input type="text" id="user_company_address" name="user_company_address" class="input_text" value="<?php echo $_POST['user_company_address'];?>"> </td>
	<td><p> &nbsp; 用户公司地址</p>
	</td>
	</tr>
	<tr><td>公司电话</td>
	<td><input type="text" id="user_company_tel" name="user_company_tel" class="input_text" value="<?php echo $_POST['user_company_tel'];?>"> </td>
	<td><p> &nbsp; 用户公司联系电话</p>
	</td>
	</tr>
	<tr><td>公司网站</td>
	<td><input type="text" id="user_company_web" name="user_company_web" class="input_text" value="<?php echo $_POST['user_company_web'];?>"> </td>
	<td><p> &nbsp; 用户公司网站</p>
	</td>
	</tr>
	<tr><td>其它备注</td>
	<td><textarea name="user_notes" style="display:inline-blokc;"><?php echo $_POST['user_notes'];?></textarea> </td>
	<td><p> &nbsp; 可备注其它信息</p>
	</td>
	</tr>

</table>

<?php if (isset($edit_user)) { ?>
	<input type="hidden" name="save_edit" value="<?php echo $_POST['user_id'];?>" />
<?php } else { ?>
	<input type="hidden" name="save" value="y" />
<?php }?>

<button type="submit" class="primary button" name="submit"><span class="check icon"></span>保存</button> 
</form>


</div>

<?php include('../View/footer.php'); ?>
