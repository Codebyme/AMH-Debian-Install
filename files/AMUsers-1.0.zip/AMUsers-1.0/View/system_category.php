<?php !defined('_Amysql') && exit; ?>

<h2>系统设计 & 功能控制</h2>
<div id="category">
<a href="index.php?c=system&a=amusers_controller" id="amusers_controller">控制器</a>
<a href="index.php?c=system&a=amusers_item" id="amusers_item">组件管理</a>
<script>
var action = '<?php echo $_GET['a'];?>';
var action_dom = G(action) ? G(action) : G('amusers_controller');
action_dom.className = 'activ';
</script>
</div>