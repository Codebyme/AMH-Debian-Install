<?php !defined('_Amysql') && exit; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo isset($title) ? $title : ' AMUsers - AMH';?></title>
<base href="<?php echo _Http;?>" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="zh-cn">
<link type="text/css" rel="stylesheet" href="View/css/index.css" />
<link type="text/css" rel="stylesheet" href="../View/css/buttons.css" />
<script src="View/js/index.js"></script>
<style>
<?php if($_SESSION['amh_config']['HelpDoc']['config_value'] == 'no') { ?>
#notice_message {display:none;}
<?php }?>
#account {
	width:200px;
	float:right;
	color: #9E9FA0;
	margin-top:10px;
}
#account a{
	border-radius: 5px;
	background: #F0F0F0;
	padding: 1px 4px;
	border: 1px solid #E6EAEC;
	color: #8894A2;
}
</style>

<script>
var HTTP_HOST = '<?php echo $_SERVER['HTTP_HOST'];?>';
</script>
</head>
<body>
<div id="header">
<a href="index.php" class="logo"></a>

<?php if (isset($_SESSION['amusers']['admin_user']) && $_SESSION['amusers']['admin_user'] == '1'){ ?>
<div id="account">身份切换 &nbsp;
<a href="./index.php" <?php echo strpos($_GET['c'], 'amusers_') !== false ? 'style="background:#fff"' : '';?> >用户</a> 
&nbsp <a href="./index.php?c=admin" <?php echo strpos($_GET['c'], 'amusers_') === false ? 'style="background:#fff"' : '';?>>管理员</a>
</div>
<?php } ?>

<div id="navigation">
<font>欢迎您, <?php echo $_SESSION['amusers']['admin_user'] == '1' ? $_SESSION['amusers']['user_name'] . ' 管理员' : $_SESSION['amusers']['user_name'] . ' 用户' ;?></font>
<?php
	if (is_array($user_grant))
	{
		foreach ($user_grant as $key=>$val)
		{
			?>
			<a href="index.php?c=amusers_<?php echo $val['controller_name_en'];?>" id="amusers_<?php echo $val['controller_name_en'];?>"><?php echo $val['controller_name_cn'];?></a>
			<?php
		}
	}
	elseif (isset($_SESSION['amusers']['admin_user']) && $_SESSION['amusers']['admin_user'] == '1')
	{
?>
<a href="index.php?c=admin" id="admin">用户权限</a>
<a href="index.php?c=system" id="system">系统设计</a>
<?php
	}
?>
<a href="index.php?c=index&a=logout" >退出</a>
<?php $action_name = $_GET['c'];?>
<script>
var action = '<?php echo $action_name;?>';
var action_dom = G(action) ? G(action) : G('home');
action_dom.className = 'activ';
</script>
</div>
</div>
