<?php

/************************************************
 * Amysql Host - AMH / AMUsers-1.0
 * Amysql.com 
 * @param Object admin 用户管理 控制器
 * Update:2013-08-16
 * 
 */

class admin extends AmysqlController
{
	public $indexs = null;
	public $admins = null;
	public $systems = null;
	public $notice = null;
	public $top_notice = null;

	// 载入数据模型(Model)
	function AmysqlModelBase()
	{
		if($this -> indexs) return;
		$this -> _class('Functions');
		$this -> indexs = $this ->  _model('indexs');
		$this -> admins = $this ->  _model('admins');
		$this -> systems = $this ->  _model('systems');
	}

	// 数据私有保护
	function DataPrivate()
	{
		if ($_SESSION['amusers']['DataPrivate'] == 'on')
		{
			$this -> status = 'error';
			$this -> notice .= "您已开启面板数据私有保护，当前AMUsers模块不可操作。";
			Return false;
		}
		Return true;
	}


	// 默认为用户列表
	function IndexAction()
	{
		$this -> user_list();
	}

	// 用户管理
	function user_list()
	{
		$this -> title = '用户管理 - AMUsers - AMH';
		$this -> AmysqlModelBase();
		Functions::CheckAdminLogin();

		// 删除用户
		if (isset($_GET['del']) && $this -> DataPrivate())
		{
			$user_id = (int)$_GET['del'];
			$amusers_user = $this -> admins -> get_amusers_user($user_id);
			if (isset($amusers_user['user_id']) && $this -> admins -> del_amusers_user($amusers_user['user_id']))
			{
				$this -> status = 'success';
				$this -> notice = "{$amusers_user['user_name']} (ID {$amusers_user['user_id']}) 删除用户成功。";
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$amusers_user['user_name']} (ID {$amusers_user['user_id']}) 删除用户失败。";
			}
		}

		// 编辑
		if (isset($_GET['edit']))
		{
			$user_id = (int)$_GET['edit'];
			$amusers_user = $this -> admins -> get_amusers_user($user_id);
			if (isset($amusers_user['user_id']))
			{
				$this -> edit_user = true;
				$_POST = $amusers_user;
				$_POST['user_password'] = '';
			}
			
		}
		// 编辑保存
		if (isset($_POST['save_edit']) && $this -> DataPrivate())
		{
			$user_id = (int)$_POST['save_edit'];
			$amusers_user = $this -> admins -> get_amusers_user($user_id);
			if (isset($amusers_user['user_id']) && $this -> admins -> edit_amusers_user())
			{
				$this -> status = 'success';
				$this -> notice = "{$amusers_user['user_name']} (ID {$amusers_user['user_id']}) 编辑用户成功。";
				$_POST = array();
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$amusers_user['user_name']} (ID {$amusers_user['user_id']}) 编辑用户失败。";
				$_POST['user_name'] = $amusers_user['user_name'];
				$_POST['user_id'] =  $amusers_user['user_id'];
				$this -> edit_user = true;
			}
		}

		// 保存用户
		if (isset($_POST['save']) && $this -> DataPrivate())
		{
			if (empty($_POST['user_name']) || empty($_POST['user_name']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填项。';
			}
			else
			{
				if ($this -> admins -> save_amusers_user($_POST))
				{
					$this -> status = 'success';
					$this -> notice = $_POST['user_name'] . ' #新增用户成功。';
					$_POST = array();
				}
				else
				{
					$this -> status = 'error';
					$this -> notice = $_POST['user_name'] . ' #新增用户失败。';
				}

			}
		}


		// 用户列表
		$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
		$page_sum = 20;
		$amusers_user_list = $this -> admins -> get_amusers_user_list($page, $page_sum);
		$total_page = ceil($amusers_user_list['sum'] / $page_sum);						
		$page_list = Functions::page('amusers_user_list', $amusers_user_list['sum'], $total_page, $page);		// 分页列表

		// 权限组名称
		$amusers_group_list_all = $this -> admins -> get_amusers_group_list_all();

		$this -> page = $page;
		$this -> total_page = $total_page;
		$this -> page_list = $page_list;
		$this -> amusers_user_list = $amusers_user_list;
		$this -> amusers_group_list_all = $amusers_group_list_all;

		$this -> indexs -> log_insert($this -> notice);
		$this -> _view('admin_user_list');
	}

	// *******************************************************************************************
	// 权限组
	function user_grant()
	{
		$this -> title = '权限组管理 - AMUsers - AMH';
		$this -> AmysqlModelBase();
		Functions::CheckAdminLogin();

		if (isset($_GET['del']) && $this -> DataPrivate())
		{
			$group_id = (int)$_GET['del'];
			$amusers_group = $this -> admins -> get_amusers_group($group_id);
			if (isset($amusers_group['group_id']) && $this -> admins -> del_amusers_group($amusers_group['group_id']))
			{
				$this -> status = 'success';
				$this -> notice = "{$amusers_group['group_name']} (ID {$amusers_group['group_id']}) 删除权限组成功。";
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$amusers_group['group_name']} (ID {$amusers_group['group_id']}) 删除权限组失败。";
			}
		}

		// 编辑
		if (isset($_GET['edit']))
		{
			$group_id = (int)$_GET['edit'];
			$amusers_group = $this -> admins -> get_amusers_group($group_id);
			if (isset($amusers_group['group_name']))
			{
				$this -> edit_group = true;
				$_POST = $amusers_group;
			}
		}
		// 编辑保存
		if (isset($_POST['save_edit']) && $this -> DataPrivate())
		{
			$_POST['group_id'] =  $_POST['save_edit'];
			if (empty($_POST['group_name']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写权限组名称。';
				$this -> edit_group = true;
			}
			elseif ($this -> admins -> edit_group_name())
			{
				$this -> status = 'success';
				$this -> notice = "{$_POST['group_name']} (ID {$_POST['save_edit']}) 编辑权限组成功。";
				$_POST = array();
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$_POST['group_name']} (ID {$_POST['save_edit']}) 编辑权限组失败。";
				$this -> edit_group = true;
			}
		}

		// 保存host
		if (isset($_POST['save']) && $this -> DataPrivate())
		{
			if (empty($_POST['group_name']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写权限组名称。';
			}
			else
			{
				if ($this -> admins -> save_group_name($_POST))
				{
					$this -> status = 'success';
					$this -> notice = $_POST['group_name'] . ' #新增权限组成功。';
					$_POST = array();
				}
				else
				{
					$this -> status = 'error';
					$this -> notice = $_POST['group_name'] . ' #新增权限组失败。';
				}

			}
		}

		// 授权管理
		if (isset($_GET['grant']))
		{
			$group_id = (int)$_GET['grant'];
			if (isset($_POST['save_grant']) && $this -> DataPrivate())
			{
				if ($this -> admins -> save_amusers_group_grant($group_id))
				{
					$this -> status = 'success';
					$this -> notice = $_POST['group_name'] . ' #授权控制器成功。';
					$_POST = array();
				}
				else
				{
					$this -> status = 'error';
					$this -> notice = $_POST['group_name'] . ' #授权控制器失败。';
				}
			}

			$amusers_controller_list_all = $this -> systems -> get_amusers_controller_list_all();	// 所有控制器
			$amusers_group_grant = $this -> admins -> get_amusers_group_grant($group_id);			// 组授权的控制器
			foreach ($amusers_group_grant as $key=>$val)
				$amusers_group_grant_arr[] = $val['controller_id'];
			foreach ($amusers_controller_list_all as $key=>$val)
			{
				if (in_array($val['controller_id'], $amusers_group_grant_arr) )
					$amusers_controller_list_all[$key]['checked'] = 1;
			}
			$this -> amusers_controller_list_all = $amusers_controller_list_all;
		}

		// 权限组列表
		$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
		$page_sum = 20;
		$amusers_group_list = $this -> admins -> get_amusers_group_list($page, $page_sum);
		$total_page = ceil($amusers_group_list['sum'] / $page_sum);						
		$page_list = Functions::page('amusers_group_list', $amusers_group_list['sum'], $total_page, $page);		// 分页列表

		$this -> page = $page;
		$this -> total_page = $total_page;
		$this -> page_list = $page_list;
		$this -> amusers_group_list = $amusers_group_list;

		$this -> indexs -> log_insert($this -> notice);
		$this -> _view('admin_group_list');
	}


}