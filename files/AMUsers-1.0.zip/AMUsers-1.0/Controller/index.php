<?php

/************************************************
 * Amysql Host - AMH / AMUsers-1.0
 * Amysql.com 
 * @param Object indexs 用户平台 控制器
 * Update:2013-08-16
 * 
 */

class index extends AmysqlController
{
	public $indexs = null;
	public $admins = null;
	public $systems = null;
	public $notice = null;
	public $top_notice = null;

	// 载入数据模型(Model)
	function AmysqlModelBase()
	{
		if($this -> indexs) return;
		$this -> _class('Functions');
		$this -> indexs = $this ->  _model('indexs');
		$this -> admins = $this ->  _model('admins');
		$this -> systems = $this ->  _model('systems');
	}


	// 面板登录
	function login()
	{
		$this -> title = '登录 - AMUsers - AMH';
		$this -> AmysqlModelBase();

		if (isset($_POST['login']))
		{
			
			$user = $_POST['user'];
			$password = $_POST['password'];
			$VerifyCode = $_POST['VerifyCode'];
			
			if(empty($user) || empty($password))
				$this -> LoginError = '请输入用户名与密码。';
			else
			{
				$amusers = $this -> indexs -> logins($user, $password);
				if($amusers)
				{
					$_SESSION['amusers'] = $amusers;
					header('location:./index.php');
					exit();
				}
				$_POST['password'] = '';
				$this -> LoginError = '账号或密码错误，登录失败。';
			}
			
		}
		$this -> _view('login');
		exit();
	}

	// 控制器默认入口
	function IndexAction()
	{
		$this -> AmysqlModelBase();
		Functions::CheckLogin();

		// 用户信息
		$c = $_GET['c'];
		$user_grant = $this -> indexs -> get_user_grant();
		$controller_html_list = '';

		// 首个控制器
		if (empty($c) && count($user_grant) > 0)
		{
			$first = current($user_grant);
			header("location: ./index.php?c=amusers_{$first['controller_name_en']}");
			exit();
		}
		elseif (isset($user_grant[$c]))
		{
			// 当前控制器 ***************
			$cinfo = $user_grant[$c];
			// 取得控制器所有组件
		    $controller_root_item = $this -> indexs -> get_controller_root_item($cinfo['controller_id']);
			foreach ($controller_root_item as $key=>$val)
				$controller_root_item[$key]['son'] = $this -> systems -> get_amusers_item_son($val['item_id']);	
			$controller_list_data = $this -> indexs -> get_controller_list_data($controller_root_item);			// 所有子项与属性数据
			// *************************

			// 响应表单
			$submit_result = $this -> indexs -> controller_item_form_submit();
			if ($submit_result)
			{
				$this -> status = $submit_result['result_s'] ? 'success' : 'error';
				$this -> notice = $submit_result['result_v'];
			}	
			$this -> indexs -> get_controller_item_html_list($controller_list_data);							// 取得HTML列表
			$this -> indexs -> get_controller_item_html_templet($this -> indexs -> controller_item_html);		// HTML模板

		}

		$this -> user_grant = $user_grant;
		$this -> indexs -> log_insert($this -> notice);
		$this -> _view('index');
	}


	// 退出
	function logout()
	{
		$this -> title = '退出 - AMUsers - AMH';
		unset($_SESSION['amusers']);
		$this -> _view('logout');
	}


}