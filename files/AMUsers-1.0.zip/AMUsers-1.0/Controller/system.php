<?php

/************************************************
 * Amysql Host - AMH / AMUsers-1.0
 * Amysql.com 
 * @param Object system 系统设计 控制器
 * Update:2013-08-16
 * 
 */

class system extends AmysqlController
{
	public $indexs = null;
	public $admins = null;
	public $systems = null;
	public $notice = null;
	public $top_notice = null;

	// 载入数据模型(Model)
	function AmysqlModelBase()
	{
		if($this -> indexs) return;
		$this -> _class('Functions');
		$this -> indexs = $this ->  _model('indexs');
		$this -> admins = $this ->  _model('admins');
		$this -> systems = $this ->  _model('systems');
	}

	// 数据私有保护
	function DataPrivate()
	{
		if ($_SESSION['amusers']['DataPrivate'] == 'on')
		{
			$this -> status = 'error';
			$this -> notice .= "您已开启面板数据私有保护，当前AMUsers模块不可操作。";
			Return false;
		}
		Return true;
	}


	// 默认方法
	function IndexAction()
	{
		$this -> amusers_controller();
	}


	// *******************************************************************************************
	// 控制器
	function amusers_controller()
	{
		$this -> title = '控制器管理 - AMUsers - AMH';
		$this -> AmysqlModelBase();
		Functions::CheckAdminLogin();

		if (isset($_GET['del']) && $this -> DataPrivate())
		{
			$controller_id = (int)$_GET['del'];
			$amusers_controller = $this -> systems -> get_amusers_controller($controller_id);
			if (isset($amusers_controller['controller_id']) && $this -> systems -> del_amusers_controller($amusers_controller['controller_id']))
			{
				$this -> status = 'success';
				$this -> notice = "{$amusers_controller['controller_name_en']} (ID {$amusers_controller['controller_id']}) 删除控制器成功。";
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$amusers_controller['controller_name_en']} (ID {$amusers_controller['controller_id']}) 删除控制器失败。";
			}
		}

		// 编辑
		if (isset($_GET['edit']))
		{
			$controller_id = (int)$_GET['edit'];
			$amusers_controller = $this -> systems -> get_amusers_controller($controller_id);
			if (isset($amusers_controller['controller_name_en']))
			{
				$this -> edit_controller = true;
				$_POST = $amusers_controller;
			}
		}
		// 编辑保存
		if (isset($_POST['save_edit']) && $this -> DataPrivate())
		{
			
			$_POST['controller_id'] =  $_POST['save_edit'];
			if (empty($_POST['controller_name_cn']) || empty($_POST['controller_name_en']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填选项。';
				$this -> edit_controller = true;
			}
			elseif ($this -> systems -> edit_amusers_controller())
			{
				$this -> status = 'success';
				$this -> notice = "{$_POST['controller_name_en']} (ID {$_POST['save_edit']}) 编辑控制器成功。";
				$_POST = array();
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$_POST['controller_name_en']} (ID {$_POST['save_edit']}) 编辑控制器失败。";
				$this -> edit_controller = true;
			}
		}

		// 保存控制器
		if (isset($_POST['save']) && $this -> DataPrivate())
		{
			if (empty($_POST['controller_name_cn']) || empty($_POST['controller_name_en']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填选项。';
			}
			else
			{
				if ($this -> systems -> save_amusers_controller($_POST))
				{
					$this -> status = 'success';
					$this -> notice = $_POST['controller_name_en'] . ' #新增控制器成功。';
					$_POST = array();
				}
				else
				{
					$this -> status = 'error';
					$this -> notice = $_POST['controller_name_en'] . ' #新增控制器失败。';
				}

			}
		}

		// 权限组列表
		$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
		$page_sum = 20;
		$amusers_controller_list = $this -> systems -> get_amusers_controller_list($page, $page_sum);
		$total_page = ceil($amusers_controller_list['sum'] / $page_sum);						
		$page_list = Functions::page('amusers_controller_list', $amusers_controller_list['sum'], $total_page, $page);		// 分页列表

		$this -> page = $page;
		$this -> total_page = $total_page;
		$this -> page_list = $page_list;
		$this -> amusers_controller_list = $amusers_controller_list;

		$this -> indexs -> log_insert($this -> notice);
		$this -> _view('system_amusers_controller');
	}




	// *******************************************************************************************
	// 组件管理
	function amusers_item()
	{
		$this -> title = '组件管理 - AMUsers - AMH';
		$this -> AmysqlModelBase();
		Functions::CheckAdminLogin();

		// 删除
		if (isset($_GET['del']) && $this -> DataPrivate())
		{
			$item_id = (int)$_GET['del'];
			$amusers_item = $this -> systems -> get_amusers_item($item_id);
			if (isset($amusers_item['item_id']) && $this -> systems -> del_amusers_item($amusers_item['item_id']))
			{
				$this -> status = 'success';
				$this -> notice = "{$amusers_item['item_name_en']} (ID {$amusers_item['item_id']}) 删除组件成功。";
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$amusers_item['item_name_en']} (ID {$amusers_item['item_id']}) 删除组件失败。";
			}
		}

		// 编辑
		if (isset($_GET['edit']))
		{
			$item_id = (int)$_GET['edit'];
			$amusers_item = $this -> systems -> get_amusers_item($item_id);
			if (isset($amusers_item['item_id']))
			{
				$this -> edit_item = true;
				$_POST = $amusers_item;
			}
		}
		// 编辑保存
		if (isset($_POST['save_edit']) && $this -> DataPrivate())
		{
			$_POST['item_id'] =  $_POST['save_edit'];
			if (empty($_POST['item_type_id']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填选项。';
				$this -> edit_item = true;
			}
			elseif ($this -> systems -> edit_amusers_item())
			{
				$this -> status = 'success';
				$this -> notice = "{$_POST['item_name']} (ID {$_POST['save_edit']}) 编辑组件成功。";
				$_POST = array();
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$_POST['item_name']} (ID {$_POST['save_edit']}) 编辑组件失败。";
				$this -> edit_item = true;
			}
		}

		// 保存组件
		if (isset($_POST['save']) && $this -> DataPrivate())
		{
			if (empty($_POST['item_type_id']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填选项。';
			}
			else
			{
				if ($this -> systems -> save_amusers_item($_POST))
				{
					$this -> status = 'success';
					$this -> notice = $_POST['item_name_en'] . ' #新增组件成功。';
					$_POST = array();
				}
				else
				{
					$this -> status = 'error';
					$this -> notice = $_POST['item_name_en'] . ' #新增组件失败。';
				}
			}
		}
		
		// 组件管理
		if (isset($_GET['item']))
		{
			$item_id = (int)$_GET['item'];
			$amusers_item_son = $this -> systems -> get_amusers_item_son($item_id);
			$this -> amusers_item_son = $amusers_item_son;
		}

		// ************

		// 删除
		if (isset($_GET['del_property']) && $this -> DataPrivate())
		{
			$property_id = (int)$_GET['del_property'];
			$amusers_property = $this -> systems -> get_amusers_property($property_id);
			if (isset($amusers_property['property_id']) && $this -> systems -> del_amusers_property($amusers_property['property_id']))
			{
				$this -> status = 'success';
				$this -> notice = "{$amusers_property['property_name']} (ID {$amusers_property['property_id']}) 删除组件属性成功。";
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "{$amusers_property['property_name']} (ID {$amusers_property['property_id']}) 删除组件属性失败。";
			}
		}

		// 保存属性
		if (isset($_POST['save_property']) && $this -> DataPrivate())
		{
			if (empty($_POST['property_name']) || empty($_POST['property_type']))
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填选项。';
			}
			else
			{
				if ($this -> systems -> save_amusers_property($_POST))
				{
					$this -> status = 'success';
					$this -> notice = '组件#ID' . $_POST['save_property'] . '新增#' . $_POST['property_name'] . '属性成功。';
					$_POST = array();
				}
				else
				{
					$this -> status = 'error';
					$this -> notice = '组件#ID' . $_POST['save_property'] . '新增#' . $_POST['property_name'] . '属性失败。';
				}
			}
		}

		// 编辑属性
		if (isset($_GET['edit_property']))
		{
			$property_id = (int)$_GET['edit_property'];
			$amusers_property = $this -> systems -> get_amusers_property($property_id);
			if (isset($amusers_property['property_id']))
			{
				$this -> edit_property = true;
				$_POST = $amusers_property;
			}
		}
		if (isset($_POST['edit_property']) && $this -> DataPrivate())
		{
			$_POST['property_id'] =  $_POST['edit_property'];
			if (empty($_POST['property_name']) || empty($_POST['property_type']) )
			{
				$this -> status = 'error';
				$this -> notice = '请填写必填选项。';
				$this -> edit_property = true;
			}
			elseif ($this -> systems -> edit_amusers_property())
			{
				$this -> status = 'success';
				$this -> notice = "#ID {$_POST['property_id']} 编辑组件属性成功。";
				$_POST = array();
			}
			else
			{
				$this -> status = 'error';
				$this -> notice = "#ID {$_POST['property_id']} 编辑组件属性失败。";
				$this -> edit_property = true;
			}
		}

		// 属性列表
		if (isset($_GET['property']))
		{
			$item_id = (int)$_GET['property'];
			$amusers_property_list = $this -> systems -> get_amusers_property_list($item_id);
			$this -> amusers_property_list = $amusers_property_list;
		}
		

		
		// 组件列表
		$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
		$page_sum = 20;
		$amusers_item_list = $this -> systems -> get_amusers_item_list($page, $page_sum);
		$total_page = ceil($amusers_item_list['sum'] / $page_sum);						
		$page_list = Functions::page('amusers_item_list', $amusers_item_list['sum'], $total_page, $page);		// 分页列表
		$amusers_controller_list_all = $this -> systems -> get_amusers_controller_list_all();
		$amusers_item_type_list_all = $this -> systems -> get_amusers_item_type_list_all();

		$this -> page = $page;
		$this -> total_page = $total_page;
		$this -> page_list = $page_list;
		$this -> amusers_item_list = $amusers_item_list;
		$this -> amusers_controller_list_all = $amusers_controller_list_all;
		$this -> amusers_item_type_list_all = $amusers_item_type_list_all;

		$this -> indexs -> log_insert($this -> notice);
		$this -> _view('system_amusers_item');
	}
}