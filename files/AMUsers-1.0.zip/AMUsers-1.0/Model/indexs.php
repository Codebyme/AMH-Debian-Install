<?php

/************************************************
 * Amysql Host - AMH / AMUsers-1.0
 * Amysql.com 
 * @param Object indexs 用户平台 数据模型
 * Update:2013-08-16
 * 
 */

class indexs extends AmysqlModel
{

	public $amusers_item_type_list_all;		// 所有类型
	public $close_tag = array('form', 'table', 'tr', 'th', 'td', 'select', 'option', 'textarea', 'font', 'h2', 'div', 'p', 'button');		// 需要闭合的标签
	public $sql_action = array('assoc' => '_row', 'array' => '_all', 'query' => '_query');

	public $controller_item_html = '<!--AMUsers-Item-ID-0-->';
	public $controller_item_php = array();				// 响应PHP代码
	public $controller_item_action =  array();			// 响应属性集合
	public $controller_item_action_data =  array();		// 响应数据
	public $controller_item_data =  array();			// 模板数据


	// 登录验证
	function logins($user, $password)
	{
		$password = md5(md5($password.'_amysql-amh'));
		$sql = "SELECT * FROM module_amusers_user WHERE user_name = '$user' AND user_password = '$password' AND user_status = 1";
		$data = $this -> _row($sql);
		if(isset($data['user_id']))
		{
			$sql = "SELECT config_value FROM amh_config WHERE config_name = 'DataPrivate'";
			$DataPrivate = $this -> _row($sql);
			$data['DataPrivate'] = $DataPrivate['config_value'];
			Return $data;
		}
		Return false;
	}


	// 日志写记录
	function log_insert($txt)
	{
		if(empty($txt)) return;
		$data['log_user_id'] = 0;
		$data['log_text'] = "AMUsers({$_SESSION['amusers']['user_name']}): " . $txt;
		$data['log_ip'] = $_SERVER["REMOTE_ADDR"];
		$this -> _insert('amh_log', $data);
	}


	// 取得用户的授权 ***********************************************
	function get_user_grant()
	{
		file_put_contents('View/index_templet.php', '');
		$sql = "SELECT * FROM module_amusers_grant AS ag LEFT JOIN module_amusers_controller AS ac ON ag.controller_id = ac.controller_id WHERE ac.controller_id IS NOT NULL AND ag.group_id = {$_SESSION['amusers']['group_id']} GROUP BY ac.controller_id ORDER BY ac.controller_order ASC";
		// if (($_SESSION['amusers']['admin_user'] == '1'))
		// 	$sql = "SELECT * FROM module_amusers_controller WHERE 1 ORDER BY controller_order ASC";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$data['amusers_' . $rs['controller_name_en']] = $rs;
		}
		Return $data;
	}
	
	// 取得控制器组件(顶级)
	function get_controller_root_item($controller_id)
	{
		$sql = "SELECT * FROM module_amusers_item WHERE controller_id = '$controller_id' AND item_parent_id = 0 ORDER BY item_order, item_id ASC";
		Return $this -> _all($sql);
	}

	// 分析取得控制器所有数据 **********************
	function get_controller_list_data($data)
	{
		global $Amysql;
		$this -> amusers_item_type_list_all = $Amysql -> AmysqlProcess -> AmysqlController -> systems -> get_amusers_item_type_list_all();
		$this -> get_controller_item_property($data);	// 取属性 & 组件类型数据
		Return $data;
	}

	// 取得控制器所有组件属性
	function get_controller_item_property(&$data)
	{
		global $Amysql;
		foreach ($data as $key=>$val)
		{
			// 取得属性列表与组件类型
			$data[$key]['property'] = $Amysql -> AmysqlProcess -> AmysqlController -> systems -> get_amusers_property_list($data[$key]['item_id']);
			$data[$key]['item_type'] = $this -> amusers_item_type_list_all[$data[$key]['item_type_id']];
			$tag = $data[$key]['item_type']['item_type_code'];

			foreach ($data[$key]['property'] as $k=>$v)
			{
				// SQL模板数据
				if (in_array($v['property_type'], array('sql_data', 'amh_data')))
					$this -> controller_item_data[] = $v;

				// PHP代码
				if(in_array($v['property_type'], array('php')))
					$this -> controller_item_php[] = $v;

				// AMH命令响应、SQL语句响应
				if(in_array($v['property_type'], array('amh', 'sql')))
					$this -> controller_item_action[] = $v;
			}
			
			if (is_array($val['son']))
				$this -> get_controller_item_property($data[$key]['son']);
		}
		
	}

	// 取得控制器所有组件HTML
	function get_controller_item_html_list($data)
	{
		foreach ($data as $key=>$val)
		{
			$tag = $data[$key]['item_type']['item_type_code'];
			$type = in_array($tag, $this -> close_tag) ? (isset($val['son'][0]) ? 'TVT' : 'TTV') : '';
			$tag_html = $this -> get_controller_item_html($tag, $data[$key]['property'], $type, $data[$key]['item_parent_id'], $data[$key]['item_id']);
			// echo "<!-- $tag_html -- $type {$data[$key]['item_parent_id']} -->";
			$this -> controller_item_html = str_replace(
				"<!--AMUsers-Item-ID-{$data[$key]['item_parent_id']}-->", $tag_html . "<!--AMUsers-Item-ID-{$data[$key]['item_parent_id']}-->", 
				$this -> controller_item_html
			);
			
			if (is_array($val['son']))
				$this -> get_controller_item_html_list($data[$key]['son']);
		}
	}

	// 取得控制器组件HTML
	function get_controller_item_html($tag, $property, $type, $item_parent_id, $item_id)
	{
		$str = '';
		$text = '';
		$str = "\n<{$tag}";
		if (is_array($property))
		{
			foreach ($property as $key=>$val)
			{
				if ($val['property_type'] == 'html')		// HTML属性
				{
					if ($val['property_name'] == 'text')
						$text .= $val['property_value'];
					else
						$str .= " {$val['property_name']}=\"{$val['property_value']}\"";
				}
			}
		}
		if (!empty($type))
		{
			$str .= ">{$text}";
			$str .= $type == 'TVT' ? "<!--AMUsers-Item-ID-{$item_id}-->" : '';
			$str .= "</{$tag}>";
		}
		else
		{
			$str .= " />";
		}

		Return $str;
	}

	// HTML模板(最后完成)
	function get_controller_item_html_templet($str)
	{
		global $Amysql;

		// 模板数据
		foreach ($this -> controller_item_data as $key=>$val)
		{
			$property_value = json_decode($val['property_value']);
			if (is_object($property_value))
			{
				$data = null;
				$property_value -> value = $this -> replace_var($property_value -> value);
				if (!empty($property_value -> value))
				{
					// 必须存在参数情况
					if (isset($property_value -> param) && !isset($_POST[$val['property_name']]) && !isset($_GET[$val['property_name']]))
						continue;
					
					// 打印调试
					if (isset($property_value -> debug))
						print_r($property_value);
					if ($val['property_type'] == 'sql_data')
					{
						$fetch = isset($this -> sql_action[$property_value -> fetch]) ? $this -> sql_action[$property_value -> fetch] : '_row';
						$data = $this -> {$fetch}($property_value -> value);
					}
					elseif ($val['property_type'] == 'amh_data')
					{
						$cmd = Functions::trim_cmd($property_value -> value);
						if(substr($cmd, 0, 3) == 'amh')
							$data = shell_exec($cmd);
					}
					if(!empty($data))
						$Amysql -> AmysqlProcess -> AmysqlController -> {$property_value -> name} = $data;
				}
			}
		}

		if(!file_put_contents('View/index_templet.php', $str))
			exit('[Error] Operation not permitted: View/index_templet.php');
	}


	// 响应表单
	function controller_item_form_submit()
	{
		// PHP代码
		file_put_contents('View/index_templet.php', '');
		foreach ($this -> controller_item_php as $key=>$val)
		{
			if (isset($_POST[$val['property_name']]) || isset($_GET[$val['property_name']]))
				file_put_contents('View/index_templet.php', file_get_contents('View/index_templet.php') . $val['property_value']);

		}
		@include('View/index_templet.php');

		// AMH命令、SQL语句以属性名字归类(ID排序)
		$action_arr = array();
		foreach ($this -> controller_item_action as $key=>$val)
		{
			$pv = json_decode($val['property_value']);
			if (is_object($pv))
				$action_arr[$val['property_name']][(int)$pv -> id] = $val;
		}
	
		$result_v = array();	// 执行提示数据值
		$result_s = false;		// 执行状态

		$break = false;
		foreach ($action_arr as $key=>$val)
		{
			if (isset($_POST[$key]) || isset($_GET[$key]))
			{
				ksort($val);
				foreach ($val as $k=>$v)
				{
					$v['property_value'] = json_decode($this -> replace_var($v['property_value']));		// 每次执行解析新变量
					// print_r($this -> controller_item_action_data);

					if (isset($v['property_value'] -> debug))											// 打印调试
						print_r($v);
					if (isset($v['property_value'] -> rules))											// 判断规则是否成立
					{
						foreach ($v['property_value'] -> rules as $rk=>$rv)
						{
							$rk = ($rk == '_empty_') ? '' : $rk;
							if(!preg_match($rv, $rk))
							{
								// 有提示信息，规则不成立即时退出
								if(isset($v['property_value'] -> notice))
								{
									$result_v[] = $v['property_value'] -> notice;
									$result_s = false;
									$break = true;
									break;
								}
								// 命令不可用
								$v['property_value'] -> disabled = true;
							}
						}
					}
					if($break) break;

					$status = NULL;
					$action_data = NULL;
					if (!empty($v['property_value'] -> value) && !isset($v['property_value'] -> disabled))
					{
						if ($v['property_type'] == 'amh')		// AMH命令响应
						{
							$cmd = Functions::trim_cmd($v['property_value'] -> value);
							if(substr($cmd, 0, 3) == 'amh')
							{
								exec($cmd, $tmp, $status);
								$status = $status ? 0 : 1;
								$action_data = array('data' => implode("\n", $tmp));
							}

						}
						elseif ($v['property_type'] == 'sql')	// SQL语句响应
						{
							$fetch = isset($this -> sql_action[$v['property_value'] -> fetch]) ? $this -> sql_action[$v['property_value'] -> fetch] : '_query';
							$tmp = $this -> {$fetch}($v['property_value'] -> value);
							$status = $tmp ? 1 : 0;
							$action_data = array('data' => $tmp, 'insert_id' => mysql_insert_id(), 'affected' => $this -> Affected);
						}
						// 记录执行结果数据
						if(isset($v['property_value'] -> name))
							$this -> controller_item_action_data[$v['property_value'] -> name] = $action_data;	

						// 执行成功
						if ($status)
						{
							if(isset($v['property_value'] -> success))
							{
								$result_v[] = $v['property_value'] -> success;
								$result_s = true;
							}
						}
						else
						{
							// 有失败提示，失败即时退出
							if(isset($v['property_value'] -> fail))
							{
								$result_v[] = $v['property_value'] -> fail;
								$result_s = false;
								$break = true;
								break;
							}
						}
					}
				}
			}
			if($break) break;
		}
		if (count($result_v) > 0)
		{
			Return array('result_v' => implode(' ', $result_v), 'result_s' => $result_s);
		}
		Return false;
	}


	// 变量替换
	function replace_var($str, $data = NULL)
	{
		if(is_array($data)) @extract($data);
		if(is_array($this -> controller_item_action_data))  @extract($this -> controller_item_action_data);

		preg_match_all('/\{\$(.*)\}/U', $str, $matches);
		if (is_array($matches[1]))
		{
			foreach ($matches[1] as $key=>$val)
			{
				preg_match_all('/([0-9a-zA-Z_]+)/', $val, $matches2);
				if (is_array($matches2[1]))
				{
					foreach ($matches2[1] as $k=>$v)
					{
						if(isset($php_val))
							$php_val = $php_val[$v];
						else
						{
							if(in_array($v, array('_SESSION', '_GET', '_POST')))
								global ${$v};
							$php_val = ${$v};
						}
					}
					$str = str_replace($matches[0][$key], $php_val, $str);
					// eval("return \$$name;");
				}
				unset($php_val);
			}
		}
	
		Return $str;
	}

	
	
}

?>