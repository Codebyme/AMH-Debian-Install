<?php

/************************************************
 * Amysql Host - AMH / AMUsers-1.0
 * Amysql.com 
 * @param Object admins 用户管理 数据模型
 * Update:2013-08-16
 * 
 */

class admins extends AmysqlModel
{

	// 取得用户
	function get_amusers_user($user_id)
	{
		$sql = "SELECT * FROM module_amusers_user WHERE user_id = '$user_id' ";
		Return $this -> _row($sql);
	}

	// 删除用户
	function del_amusers_user($user_id)
	{
		$sql = "DELETE FROM module_amusers_user WHERE user_id = '$user_id' ";
		Return $this -> _query($sql);
	}

	// 保存用户
	function save_amusers_user()
	{
		$field_array = array('group_id', 'user_name', 'user_info_name', 'user_info_email', 'user_info_qq', 'user_info_tel', 'user_company_name', 'user_company_address', 'user_company_tel', 'user_company_web', 'user_status', 'user_notes', 'admin_user');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];
		$data['user_password'] = md5(md5($_POST['user_password'] . '_amysql-amh'));
		Return $this -> _insert('module_amusers_user', $data);
	}

	// 编辑用户
	function edit_amusers_user()
	{
		$user_id = (int)$_POST['save_edit'];
		$field_array = array('group_id', 'user_info_name', 'user_info_email', 'user_info_qq', 'user_info_tel', 'user_company_name', 'user_company_address', 'user_company_tel', 'user_company_web', 'user_status', 'user_notes', 'admin_user');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];

		if (isset($_POST['user_password']) && !empty($_POST['user_password']))
			$data['user_password'] = md5(md5($_POST['user_password'] . '_amysql-amh'));
		Return $this -> _update('module_amusers_user', $data, " WHERE user_id = '$user_id' ");
	}

	// 取得权限组列表(所有)
	function get_amusers_group_list_all()
	{
		$sql = "SELECT * FROM module_amusers_group ORDER BY group_id ASC ";
		Return $this -> _all($sql);
	}


	// 取得用户列表
	function get_amusers_user_list($page = 1, $page_sum = 20)
	{
		$sql = "SELECT * FROM module_amusers_user AS au LEFT JOIN module_amusers_group ag ON au.group_id = ag.group_id ";
		$sum = $this -> _sum($sql);

		$limit = ' LIMIT ' . ($page-1)*$page_sum . ' , ' . $page_sum;
		$sql = "SELECT * FROM module_amusers_user AS au LEFT JOIN module_amusers_group ag ON au.group_id = ag.group_id ORDER BY user_id ASC $limit";
		Return array('data' => $this -> _all($sql), 'sum' => $sum);
	}


	// *********************************************************
	// 取得权限组
	function get_amusers_group($group_id)
	{
		$sql = "SELECT * FROM module_amusers_group WHERE group_id = '$group_id'";
		Return $this -> _row($sql);
	}


	// 取得权限组列表
	function get_amusers_group_list($page = 1, $page_sum = 20)
	{
		$sql = "SELECT * FROM module_amusers_group";
		$sum = $this -> _sum($sql);

		$limit = ' LIMIT ' . ($page-1)*$page_sum . ' , ' . $page_sum;
		$sql = "SELECT * FROM module_amusers_group ORDER BY group_id ASC $limit";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$group_id = $rs['group_id'];
			$sql = "SELECT user_id FROM module_amusers_user WHERE group_id = '$group_id'";
			$rs['user_sum'] = $this -> _sum($sql);
			$data[] = $rs;
		}
		Return array('data' => $data, 'sum' => $sum);
	}

	// 权限组
	function save_group_name()
	{
		$group_name = $_POST['group_name'];
		$sql = "INSERT INTO module_amusers_group(group_name) VALUES('$group_name')";
		Return $this -> _query($sql);
	}

	// 编辑组
	function edit_group_name()
	{
		$group_id = (int)$_POST['save_edit'];
		$group_name = $_POST['group_name'];
		$sql = "UPDATE module_amusers_group SET group_name = '$group_name' WHERE group_id = '$group_id' ";
		Return $this -> _query($sql);
	}

	// 删除组
	function del_amusers_group($group_id)
	{
		$sql = "DELETE FROM module_amusers_group WHERE group_id = '$group_id'";
		Return $this -> _query($sql);
	}
	
	// 取得组的授权
	function get_amusers_group_grant($group_id)
	{
		$sql = "SELECT controller_id FROM module_amusers_grant WHERE group_id = '$group_id'";
		Return $this -> _all($sql);
	}
	// 删除组的授权
	function del_amusers_group_grant($group_id)
	{
		$sql = "DELETE FROM module_amusers_grant WHERE group_id = '$group_id'";
		Return $this -> _query($sql);
	}

	// 保存组的授权
	function save_amusers_group_grant($group_id)
	{
		$this -> del_amusers_group_grant($group_id);
		foreach ($_POST as $key=>$val)
		{
			if (strpos($key, 'controller_id_') !== false && $val == 'on')
			{
				$id_arr = explode('_', $key);
				$insert_data = array('controller_id' => (int)$id_arr[2], 'group_id' => (int)$group_id);
				$this -> _insert('module_amusers_grant', $insert_data);
			}
		}
		Return $this -> Affected;
	}
}

?>