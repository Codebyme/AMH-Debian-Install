<?php

/************************************************
 * Amysql Host - AMH / AMUsers-1.0
 * Amysql.com 
 * @param Object systems 系统设计 数据模型
 * Update:2013-08-16
 * 
 */

class systems extends AmysqlModel
{
	public $amusers_item_son_id = array();

	// 取得控制器
	function get_amusers_controller($controller_id)
	{
		$sql = "SELECT * FROM module_amusers_controller WHERE controller_id = '$controller_id'";
		Return $this -> _row($sql);
	}


	// 取得控制器列表
	function get_amusers_controller_list($page = 1, $page_sum = 20)
	{
		$sql = "SELECT * FROM module_amusers_controller";
		$sum = $this -> _sum($sql);

		$limit = ' LIMIT ' . ($page-1)*$page_sum . ' , ' . $page_sum;
		$sql = "SELECT * FROM module_amusers_controller ORDER BY controller_id ASC $limit";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$data[] = $rs;
		}
		Return array('data' => $data, 'sum' => $sum);
	}

	// 保存控制器
	function save_amusers_controller()
	{
		$field_array = array('controller_name_cn', 'controller_name_en', 'controller_order');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];
		Return $this -> _insert('module_amusers_controller', $data);
	}

	// 编辑控制器
	function edit_amusers_controller()
	{
		$controller_id = (int)$_POST['save_edit'];
		$field_array = array('controller_name_cn', 'controller_name_en', 'controller_order');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];

		Return $this -> _update('module_amusers_controller', $data, " WHERE controller_id = '$controller_id' ");
	}

	// 删除控制器
	function del_amusers_controller($controller_id)
	{
		$sql = "DELETE FROM module_amusers_controller WHERE controller_id = '$controller_id'";
		Return $this -> _query($sql);
	}



	// *********************************************************

	// 取得组件
	function get_amusers_item($item_id)
	{
		$sql = "SELECT * FROM module_amusers_item WHERE item_id = '$item_id'";
		Return $this -> _row($sql);
	}
	// 取得子组件(递归所有)
	function get_amusers_item_son($item_id)
	{
		$data = array();
		$sql = "SELECT * FROM module_amusers_item WHERE item_parent_id = '$item_id' ORDER BY item_order, item_id ASC";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$this -> amusers_item_son_id[] = $rs['item_id'];			// 保存ID
			$rs['son'] = $this -> get_amusers_item_son($rs['item_id']);
			$data[] = $rs;
		}
		Return $data;
	}


	// 删除组件
	function del_amusers_item($item_id)
	{
		$this -> amusers_item_son_id[] = $item_id;
		$this -> get_amusers_item_son($item_id);	// 取得所有子组件ID
		$sql = "DELETE FROM module_amusers_item WHERE item_id IN ('" . implode("','", $this -> amusers_item_son_id) . "')";
		Return $this -> _query($sql);
	}


	// 取得组件列表
	function get_amusers_item_list($page = 1, $page_sum = 20)
	{
		$sql = "SELECT * FROM module_amusers_item WHERE item_parent_id = 0 ";
		$sum = $this -> _sum($sql);

		$limit = ' LIMIT ' . ($page-1)*$page_sum . ' , ' . $page_sum;
		$sql = "SELECT * FROM module_amusers_item WHERE item_parent_id = 0 ORDER BY item_order,item_id ASC $limit";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$data[] = $rs;
		}
		Return array('data' => $data, 'sum' => $sum);
	}

	// 取控制器列表(所有)
	function get_amusers_controller_list_all()
	{
		$sql = "SELECT * FROM module_amusers_controller ORDER BY controller_order ASC";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$data[$rs['controller_id']] = $rs;
		}
		Return $data;
	}

	// 取组件类型(所有)
	function get_amusers_item_type_list_all()
	{
		$sql = "SELECT * FROM module_amusers_item_type ORDER BY item_type_order ASC";
		$result = $this -> _query($sql);
		while ($rs = mysql_fetch_assoc($result))
		{
			$data[$rs['item_type_id']] = $rs;
		}
		Return $data;
	}

	// 保存组件
	function save_amusers_item()
	{
		$field_array = array('controller_id' , 'item_type_id', 'item_parent_id', 'item_order', 'item_note');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];
		Return $this -> _insert('module_amusers_item', $data);
	}

	// 编辑组件
	function edit_amusers_item()
	{
		$item_id = (int)$_POST['save_edit'];
		$field_array = array('item_parent_id', 'controller_id', 'item_type_id', 'item_order', 'item_note');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];
		Return $this -> _update('module_amusers_item', $data, " WHERE item_id = '$item_id' ");
	}

	// *******************************
	// 取得组件属性
	function get_amusers_property($property_id)
	{
		$sql = "SELECT * FROM module_amusers_item_property WHERE property_id = '$property_id'";
		Return $this -> _row($sql);
	}

	// 取得组件属性列表
	function get_amusers_property_list($item_id)
	{
		$sql = "SELECT * FROM module_amusers_item_property WHERE item_id = '$item_id'";
		Return $this -> _all($sql);
	}

	// 保存组件属性
	function save_amusers_property()
	{
		$_POST['item_id'] = (int)$_POST['save_property'];
		$field_array = array('item_id' , 'property_type', 'property_name', 'property_value');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];
		Return $this -> _insert('module_amusers_item_property', $data);
	}

	// 编辑组件属性
	function edit_amusers_property()
	{
		$property_id = (int)$_POST['property_id'];
		$field_array = array('property_type', 'property_name', 'property_value');
		foreach ($field_array as $val)
			$data[$val] = $_POST[$val];
		Return $this -> _update('module_amusers_item_property', $data, " WHERE property_id = '$property_id' ");
	}

	// 删除组件属性
	function del_amusers_property($property_id)
	{
		$sql = "DELETE FROM module_amusers_item_property WHERE property_id = '$property_id'";
		Return $this -> _query($sql);
	}

}

?>