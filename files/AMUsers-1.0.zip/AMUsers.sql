use `amh`;

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_controller`
--

CREATE TABLE IF NOT EXISTS `module_amusers_controller` (
  `controller_id` int(10) NOT NULL AUTO_INCREMENT,
  `controller_name_cn` varchar(30) NOT NULL,
  `controller_name_en` varchar(30) NOT NULL,
  `controller_order` int(3) NOT NULL,
  `controller_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`controller_id`),
  UNIQUE KEY `controller_name_en` (`controller_name_en`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_grant`
--

CREATE TABLE IF NOT EXISTS `module_amusers_grant` (
  `grant_id` int(10) NOT NULL AUTO_INCREMENT,
  `group_id` int(10) NOT NULL,
  `controller_id` int(10) NOT NULL,
  PRIMARY KEY (`grant_id`),
  UNIQUE KEY `group_id` (`group_id`,`controller_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_group`
--

CREATE TABLE IF NOT EXISTS `module_amusers_group` (
  `group_id` int(10) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) NOT NULL,
  `group_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `group_name` (`group_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_item`
--

CREATE TABLE IF NOT EXISTS `module_amusers_item` (
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `controller_id` int(10) NOT NULL,
  `item_parent_id` int(10) NOT NULL,
  `item_type_id` int(10) NOT NULL,
  `item_order` int(3) NOT NULL,
  `item_note` varchar(100) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `controller_id` (`controller_id`),
  KEY `item_parent_id` (`item_parent_id`),
  KEY `item_type_id` (`item_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=226 ;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_item_property`
--

CREATE TABLE IF NOT EXISTS `module_amusers_item_property` (
  `property_id` int(10) NOT NULL AUTO_INCREMENT,
  `item_id` int(10) NOT NULL,
  `property_type` varchar(20) NOT NULL,
  `property_name` varchar(20) NOT NULL,
  `property_value` text NOT NULL,
  PRIMARY KEY (`property_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=242 ;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_item_type`
--

CREATE TABLE IF NOT EXISTS `module_amusers_item_type` (
  `item_type_id` int(10) NOT NULL AUTO_INCREMENT,
  `item_type_name` varchar(20) NOT NULL,
  `item_type_code` varchar(20) NOT NULL,
  `item_type_order` int(3) NOT NULL,
  PRIMARY KEY (`item_type_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------
INSERT INTO `module_amusers_item_type` (`item_type_id`, `item_type_name`, `item_type_code`, `item_type_order`) VALUES
(1, '表单 FORM', 'form', 1),
(2, '表格 TABLE', 'table', 2),
(3, '表格行 TR', 'tr', 3),
(4, '表格列 TD', 'td', 4),
(7, '文本 FONT', 'font', -7),
(8, ' INPUT 元素', 'input', 8),
(9, '下拉框 SELECT', 'select', 9),
(18, '区域 DIV', 'div', -10),
(13, '多行输入框 TEXTAREA', 'textarea', 13),
(14, '图像 IMG', 'img', 14),
(15, '表格列 TH', 'th', 4),
(19, '换行 P', 'p', -8),
(20, '按钮 BUTTON', 'button', 8),
(17, '标题 H2', 'h2', -9),
(16, '下拉项 OPTION', 'option', 9);


--
-- 表的结构 `module_amusers_product`
--

CREATE TABLE IF NOT EXISTS `module_amusers_product` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(20) NOT NULL COMMENT '产品名字',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='产品列表' AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_user`
--

CREATE TABLE IF NOT EXISTS `module_amusers_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `group_id` int(10) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `user_info_name` varchar(20) NOT NULL,
  `user_info_email` varchar(50) NOT NULL,
  `user_info_qq` varchar(20) NOT NULL,
  `user_info_tel` varchar(30) NOT NULL,
  `user_company_name` varchar(50) NOT NULL,
  `user_company_address` varchar(250) NOT NULL,
  `user_company_tel` varchar(30) NOT NULL,
  `user_company_web` varchar(80) NOT NULL,
  `user_status` int(1) NOT NULL,
  `user_notes` text NOT NULL,
  `admin_user` int(1) NOT NULL COMMENT '是否管理员',
  `user_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;
INSERT INTO `module_amusers_user` (`user_id`, `group_id`, `user_name`, `user_password`, `user_info_name`, `user_info_email`, `user_info_qq`, `user_info_tel`, `user_company_name`, `user_company_address`, `user_company_tel`, `user_company_web`, `user_status`, `user_notes`, `admin_user`) VALUES
(4, 6, 'admin', '1f6ddd05370761ebb6a0fdc7c4c1fc32', '', '', '', '', '', '', '', '', 1, '', 1);
-- --------------------------------------------------------

--
-- 表的结构 `module_amusers_user_product`
--

CREATE TABLE IF NOT EXISTS `module_amusers_user_product` (
  `user_product_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `connect_id` int(10) NOT NULL COMMENT '关联AMH 数据ID',
  `connect_txt` varchar(100) NOT NULL COMMENT '关联AMH 数据文本',
  `product_id` int(10) NOT NULL COMMENT '产品ID',
  PRIMARY KEY (`user_product_id`),
  KEY `user_id` (`user_id`),
  KEY `connect_id` (`connect_id`),
  KEY `product_type` (`product_id`),
  KEY `connect_txt` (`connect_txt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='用户产品' AUTO_INCREMENT=40 ;
